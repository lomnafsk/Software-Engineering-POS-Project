
package entities;

import java.util.ArrayList;

public class ProductCategory {
    
    private int id;
    private String name;
    private String dateCreated;
    
    // one to many product items
    private ArrayList<ProductItems> productItemses;

    public ArrayList<ProductItems> getProductItemses() {
        return productItemses;
    }

    public void setProductItemses(ArrayList<ProductItems> productItemses) {
        this.productItemses = productItemses;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }
    
}
