
package entities;

import java.util.ArrayList;

public class Purchase {
    
    private int id;
    private int cashierId;
    private String date;
    private String time;
    private String productBarcode;
    private String quantity;
    private String totalAmount;
    
    // one to one transaction
    private Transaction transaction;
    
    // one to many product items
    private ArrayList<ProductItems> productItemses;

    public ArrayList<ProductItems> getProductItemses() {
        return productItemses;
    }

    public void setProductItemses(ArrayList<ProductItems> productItemses) {
        this.productItemses = productItemses;
    }
    

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCashierId() {
        return cashierId;
    }

    public void setCashierId(int cashierId) {
        this.cashierId = cashierId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getProductBarcode() {
        return productBarcode;
    }

    public void setProductBarcode(String productBarcode) {
        this.productBarcode = productBarcode;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    
    
}
