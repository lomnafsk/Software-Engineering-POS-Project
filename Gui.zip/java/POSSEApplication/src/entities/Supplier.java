
package entities;

import java.util.ArrayList;

public class Supplier {
    
    private int id;
    private String name;
    private String lastDateSupplied;
    
    // one to many product items
    private ArrayList<ProductItems> productItemses;

    public ArrayList<ProductItems> getProductItemses() {
        return productItemses;
    }

    public void setProductItemses(ArrayList<ProductItems> productItemses) {
        this.productItemses = productItemses;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastDateSupplied() {
        return lastDateSupplied;
    }

    public void setLastDateSupplied(String lastDateSupplied) {
        this.lastDateSupplied = lastDateSupplied;
    }
    
}
