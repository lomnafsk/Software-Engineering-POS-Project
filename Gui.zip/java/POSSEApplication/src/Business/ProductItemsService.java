
package Business;

import DataAccess.ProductItemsDA;
import entities.ProductItems;
import java.util.ArrayList;
import java.sql.SQLException;

public class ProductItemsService {

    private final ProductItemsDA productItemsDA;
    
    public ProductItemsService() {
        productItemsDA = new ProductItemsDA();
    }
    
    public ArrayList<ProductItems> findAll() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        return productItemsDA.findAll();
    }
    
    public ProductItems findById(int barcode) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return productItemsDA.findById(barcode);
    }
    
    public boolean save(ProductItems productItems) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return productItemsDA.save(productItems);
    }
    
    public boolean update(ProductItems productItems) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
            return productItemsDA.update(productItems);
    }
    
    public boolean delete(int barcode) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return productItemsDA.delete(barcode);
    }
    
    
    
    
}
