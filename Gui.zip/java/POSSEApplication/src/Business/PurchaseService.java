
package Business;

import DataAccess.PurchaseDA;
import entities.Purchase;
import java.util.ArrayList;
import java.sql.SQLException;

public class PurchaseService {

    private final PurchaseDA purchaseDA;
    
    public PurchaseService() {
        purchaseDA = new PurchaseDA();
    }
    
    public ArrayList<Purchase> findAll() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{
        return purchaseDA.findAll();
    }
    
    public Purchase findById(int id) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return purchaseDA.findById(id);
    }
    
    public boolean save(Purchase purchase) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return purchaseDA.save(purchase);
    }
    
    public boolean update(Purchase purchase) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return purchaseDA.update(purchase);
    }
    
    public boolean delete(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return purchaseDA.delete(id);
    }
    
}
