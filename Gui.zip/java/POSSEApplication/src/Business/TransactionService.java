
package Business;

import DataAccess.TransactionDA;
import entities.Transaction;
import java.util.ArrayList;
import java.sql.SQLException;

public class TransactionService {

    private final TransactionDA transactionDA;
    
    public TransactionService() {
        transactionDA = new TransactionDA();
    }
    
    public ArrayList<Transaction> findAll() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        return transactionDA.findAll();
    }
    
    public Transaction findById(int id) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return transactionDA.findById(id);
    }
    
    public boolean save(Transaction transaction) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return transactionDA.save(transaction);
    }
    
    public boolean update(Transaction transaction) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return transactionDA.update(transaction);
    }
    
    public boolean delete(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return transactionDA.delete(id);
    }
    
}
