
package Business;

import DataAccess.CashierDA;
import entities.Cashier;
import java.util.ArrayList;
import java.sql.SQLException;

public class CashierService {
    
    private final CashierDA cashierDA;

    public CashierService() {
        cashierDA = new CashierDA();
    }
    
    public ArrayList<Cashier> findAll() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return cashierDA.findAll();
    }
    
    public Cashier findById(int id) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return cashierDA.findById(id);
    }
    
    public boolean save(Cashier cashier) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return cashierDA.save(cashier);
    }
    
    public boolean update(Cashier cashier) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return cashierDA.update(cashier);
    }
    
    public boolean delete(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return cashierDA.delete(id);
    }
    
    
}
