
package Business;

import DataAccess.ProductCategoryDA;
import entities.ProductCategory;
import java.util.ArrayList;
import java.sql.SQLException;

public class ProductCategoryService {

    private final ProductCategoryDA productCategoryDA;
    
    public ProductCategoryService() {
    
        productCategoryDA = new ProductCategoryDA();
    }
    
    public ArrayList<ProductCategory> findAll() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return productCategoryDA.findAll();
    }
    
    public ProductCategory findById(int id) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return productCategoryDA.findById(id);
    }
    
    public boolean save(ProductCategory productCategory) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return productCategoryDA.save(productCategory);
    }
    
    public boolean update(ProductCategory productCategory) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return productCategoryDA.update(productCategory);
    }
    
    public boolean delete(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return productCategoryDA.delete(id);
    }
}
