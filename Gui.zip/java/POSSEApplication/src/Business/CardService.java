
package Business;

import entities.Card;
import DataAccess.CardDA;
import java.sql.SQLException;
import java.util.ArrayList;

public class CardService {

    private final CardDA cardDA;
    
    public CardService() {
        cardDA = new CardDA();
    }
    
    public ArrayList<Card> findAll() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{
        return cardDA.findAll();
    }
    
    public Card findById(int customerId) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return cardDA.findById(customerId);
    }
    
    public boolean save(Card card) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return cardDA.save(card);
    }
    
    public boolean update(Card card) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return cardDA.update(card);
    }
    
    public boolean delete(int customerId) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return cardDA.delete(customerId);
    }
    
}
