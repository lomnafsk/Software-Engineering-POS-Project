
package Business;

import DataAccess.SupplierDA;
import entities.Supplier;
import java.util.ArrayList;
import java.sql.SQLException;

public class SupplierService {
    
    private final SupplierDA supplierDA;

    public SupplierService() {
        supplierDA = new SupplierDA();
    }
    
    public ArrayList<Supplier> findAll() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException{
        return supplierDA.findAll();
    }
    
    public Supplier findById(int id) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return supplierDA.findById(id);
    }
    
    public boolean save(Supplier supplier) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return supplierDA.save(supplier);
    }
    
    public boolean update(Supplier supplier) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return supplierDA.update(supplier);
    }
    
    public boolean delete(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return supplierDA.delete(id);
    }
}
