package Business;

import DataAccess.CustomerDA;
import entities.Customer;
import java.sql.SQLException;
import java.util.ArrayList;

public class CustomerService {

    private final CustomerDA customerDA;

    public CustomerService() {

        customerDA = new CustomerDA();
    }

    public ArrayList<Customer> findAll() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        return customerDA.findAll();
    }

    public Customer findById(int id) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {

        return customerDA.findById(id);

    }

    public boolean save(Customer customer) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {

        return customerDA.save(customer);
    }
    
    public boolean update(Customer customer) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return customerDA.update(customer);
    }
    
    public boolean delete(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return customerDA.delete(id);
    }

}
