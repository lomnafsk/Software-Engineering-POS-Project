

package Business;

import DataAccess.PromotionDA;
import entities.Promotion;
import java.util.ArrayList;
import java.sql.SQLException;

public class PromotionService {

    private final PromotionDA promotionDA;
    
    public PromotionService() {
        promotionDA = new PromotionDA();
    }
    
    public ArrayList<Promotion> findAll() throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return promotionDA.findAll();
    }
    
    public Promotion findById(int id) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return promotionDA.findById(id);
    }
    
    public boolean save(Promotion promotion) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException {
        return promotionDA.save(promotion);
    }
    
    public boolean update(Promotion promotion) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return promotionDA.update(promotion);
    }
    
    public boolean delete(int id) throws ClassNotFoundException, InstantiationException, IllegalAccessException, SQLException {
        return promotionDA.delete(id);
    }
}
